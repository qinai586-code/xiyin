"""Read-only integrity audit for ceiling-01 evidence; never opens the blind key."""
from __future__ import annotations

import json
import hashlib
from pathlib import Path
import subprocess


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
HEAD = "48f2b930fbcae54425d3a1c66754af25f64692a0"
MODEL_HASHES = {"q4": "13c16f426047e2de38cd075bdade4a7bcbc8c774384876f677740cda65f8a983", "q8": "5c74c0ede371924357dff0cb6ba145bd67208b9b2389ded681adfff3f7608db7", "q9": "d784ce9eda1a5a7b51e8f705a9e6310844bf4f173654d115823c775fdea56d43"}
SOURCE_HASHES = {"v5": "f68137457119094bef4d4d6d4367f87d3efe6f4e4ac737cca19147f983ed4021", "v4": "8ed5815e21c26fb1ab21bb8e0d959f9ff652d975b1a5a365c16329801f7bde93"}
ARMS = {
    "q4b-q4": 81,
    "q4b-q4-v4src": 81,
    "q4b-q4-nomenu": 81,
    "q4b-q4-preset": 81,
    "q4b-q4-think": 9,
    "q4b-q8": 81,
    "q4b-q8-v4src": 81,
    "q9b-q4": 81,
    "q9b-q4-v4src": 81,
    "q9b-q4-think": 9,
}


def audit() -> dict:
    failures = []
    arms = {}
    preset = json.loads((ROOT / "config/sampling/qwen3.5-nonthinking.candidate.json").read_text(encoding="utf-8"))["values"]
    def status_ok(name):
        path = OUT / "logs" / f"{name}.status.json"
        if not path.is_file():
            failures.append(f"missing command status: {name}")
        else:
            record = json.loads(path.read_text(encoding="utf-8"))
            if record.get("exit_code") != 0:
                failures.append(f"nonzero command: {name}")
        for suffix in ("log", "gpu.jsonl"):
            if not (OUT / "logs" / f"{name}.{suffix}").is_file():
                failures.append(f"missing raw log: {name}.{suffix}")
    for label, expected in ARMS.items():
        path = OUT / f"probe-{label}.json"
        if not path.is_file():
            failures.append(f"missing arm: {label}")
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        turns = data.get("turns") or []
        errors = sum(bool(sample.get("error")) for turn in turns for sample in turn.get("samples", []))
        bad_seeds = sum([sample.get("seed") for sample in turn.get("samples", [])] != list(range(1000, 1008))
                        for turn in turns)
        arms[label] = {"turns": len(turns), "samples": sum(len(turn.get("samples", [])) for turn in turns),
                       "errors": errors, "bad_seed_rows": bad_seeds}
        if data.get("label") != label or len(turns) != expected or errors or bad_seeds:
            failures.append(f"arm integrity: {label}")
        model = "q9" if label.startswith("q9") else "q8" if label.startswith("q4b-q8") else "q4"
        arm = data.get("arm") or {}
        source = "v4" if "v4src" in label else "v5"
        if data.get("code_revision") != HEAD or arm.get("identity", {}).get("file", {}).get("sha256") != MODEL_HASHES[model]:
            failures.append(f"model/code identity: {label}")
        if [s.get("sha256") for s in data.get("sources", [])] != [SOURCE_HASHES[source]]:
            failures.append(f"source identity: {label}")
        expected_sampling = preset if "preset" in label else {}
        if arm.get("sent_sampling") != expected_sampling or arm.get("thinking") != ("think" in label) or arm.get("ablations") != (["tool_menu"] if "nomenu" in label else []):
            failures.append(f"arm settings: {label}")
        if arm.get("samples") != 8 or arm.get("seed") != 1000 or not arm.get("server", {}).get("available"):
            failures.append(f"sampling/server evidence: {label}")
        server_model = Path(arm.get("server", {}).get("server", {}).get("model_path", "")).name
        if server_model != arm.get("identity", {}).get("file", {}).get("name"):
            failures.append(f"server/model path mismatch: {label}")
        status_ok(f"probe-{label}.json")
    full = {}
    for projection in ("v5", "v4"):
        for repeat in (1, 2, 3):
            label = f"qwen9b-q4-{projection}-r{repeat}"
            path = OUT / label / "dialogue.json"
            if not path.is_file():
                failures.append(f"missing full run: {label}")
                continue
            data = json.loads(path.read_text(encoding="utf-8"))
            n_turns = sum(len(case.get("turns", [])) for case in data.get("cases", []))
            full[label] = {"turns": n_turns, "totals": data.get("totals"),
                           "projection": data.get("persona_projection"),
                           "model": data.get("model")}
            if n_turns != 81 or data.get("persona_projection") != projection:
                failures.append(f"full run integrity: {label}")
            model = data.get("model", {})
            if data.get("label") != label or data.get("code_revision") != HEAD or model.get("identity", {}).get("file", {}).get("sha256") != MODEL_HASHES["q9"]:
                failures.append(f"full run identity: {label}")
            if model.get("sent_sampling") != {} or model.get("enable_thinking") is not False or not model.get("server_sampling", {}).get("available"):
                failures.append(f"full run settings: {label}")
            if data.get("totals", {}).get("error") or data.get("production_data_used") is not False:
                failures.append(f"full run error/isolation: {label}")
            status_ok(f"{label}__dialogue.json")
    review_path = OUT / "reviewer" / "ceiling-review.json"
    if review_path.is_file():
        review = json.loads(review_path.read_text(encoding="utf-8"))
        review_summary = {"items": len(review.get("items") or []),
                          "candidate_counts": [len(item.get("candidates") or [])
                                               for item in review.get("items") or []]}
        if review_summary["items"] != 24 or any(n != 10 for n in review_summary["candidate_counts"]):
            failures.append("blind packet dimensions")
    else:
        review_summary = None
        failures.append("missing blind reviewer packet")
    git = subprocess.run(["git", "status", "--porcelain", "--untracked-files=no"], cwd=ROOT,
                         capture_output=True, text=True, encoding="utf-8", errors="replace")
    tracked_changes = git.stdout.strip()
    if git.returncode or tracked_changes:
        failures.append("tracked worktree changed")
    manifest = json.loads((OUT / "source-manifest.json").read_text(encoding="utf-8"))
    for row in manifest["files"]:
        path = ROOT / row["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            failures.append(f"source hash drift: {row['path']}")
    for phase in ("q4-default", "q8-default", "q9-default", "q9full-native-default"):
        path = OUT / "logs" / f"server-{phase}.json"
        if not path.is_file() or json.loads(path.read_text(encoding="utf-8")).get("server_sha256") != "55c40cebb08cb596247c379328c58b9b2539b50e1e52089fb957010500eadffb":
            failures.append(f"server binary evidence: {phase}")
    screen = OUT / "screen-all.json"
    screened = json.loads(screen.read_text(encoding="utf-8")) if screen.is_file() else []
    if len(screened) != len(ARMS) or {r["label"] for r in screened} != set(ARMS):
        failures.append("screen-all coverage")
    for row in screened:
        expected = ARMS.get(row.get("label"))
        if expected is None or row.get("turns") != expected or row.get("samples") != expected * 8 or row.get("errors") != 0:
            failures.append(f"screen-all counts/errors: {row.get('label')}")
    compare = OUT / "compare-all.status.json"
    if not compare.is_file() or json.loads(compare.read_text(encoding="utf-8")).get("exit_code") != 0:
        failures.append("compare missing or failed")
    for name in ("compare-all.stdout.log", "compare-all.stderr.log", "logs/pipeline-screen.status.json", "logs/pipeline-blind.status.json"):
        if not (OUT / name).is_file():
            failures.append(f"missing delivery evidence: {name}")
        elif name.endswith(".status.json") and json.loads((OUT / name).read_text(encoding="utf-8")).get("exit_code") != 0:
            failures.append(f"nonzero delivery command: {name}")
    return {"status": "PASS" if not failures else "FAIL", "failures": failures,
            "arms": arms, "full_runs": full, "blind_packet": review_summary,
            "tracked_changes": tracked_changes}


if __name__ == "__main__":
    print(json.dumps(audit(), ensure_ascii=False, indent=2))
