"""Finish only after every preset ceiling-01 arm exists and passes integrity checks."""
from __future__ import annotations

import json
from pathlib import Path
import socket
import sys
import hashlib
import zipfile
from datetime import datetime, timezone

import audit_final
import continue_ceiling
import finalize_after_pipeline
import factual_review


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
PY = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> None:
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 8080)) == 0:
            raise RuntimeError("model server still active; wait for q9 phase completion")
    for labels in continue_ceiling.LABELS.values():
        for label in labels:
            if not continue_ceiling.output_complete(label):
                raise RuntimeError(f"incomplete arm: {label}")
    for projection in ("v5", "v4"):
        for repeat in (1, 2, 3):
            label = f"qwen9b-q4-{projection}-r{repeat}"
            path = OUT / label / "dialogue.json"
            if not path.is_file():
                raise RuntimeError(f"missing full dialogue: {label}")
            data = json.loads(path.read_text(encoding="utf-8"))
            n = sum(len(case.get("turns", [])) for case in data.get("cases", []))
            if n != 81 or data.get("persona_projection") != projection or data.get("totals", {}).get("error"):
                raise RuntimeError(f"invalid full dialogue: {label}")
    probes = sorted(OUT.glob("probe-*.json"))
    continue_ceiling.run("screen", [str(PY), "-B", "tools/ceiling_probe.py", "screen",
                                    *map(str, probes), "--out", str(OUT / "screen-all.json")])
    continue_ceiling.blind_preflight()
    continue_ceiling.run("blind", [str(PY), "-B", "tools/ceiling_probe.py", "blind",
                                   str(OUT / "probe-q4b-q4.json"),
                                   str(OUT / "probe-q4b-q8.json"),
                                   str(OUT / "probe-q9b-q4.json"),
                                   "--per-arm", "3", "--seed", "20260924",
                                   "--review", str(OUT / "reviewer" / "ceiling-review.json"),
                                   "--key", str(OUT / "keys" / "ceiling-key.json")])
    factual_review.build()
    if not finalize_after_pipeline.compare_if_ready():
        raise RuntimeError("required 4B/9B compare failed or source reports missing")
    audit = audit_final.audit()
    (OUT / "audit-final.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    if audit["status"] != "PASS":
        raise RuntimeError(f"final integrity audit failed: {audit['failures']}")
    review_archive = ROOT / "CEILING_BLIND_REVIEW_ONLY.zip"
    if review_archive.exists():
        raise RuntimeError("review-only archive already exists")
    with zipfile.ZipFile(review_archive, "w", compression=zipfile.ZIP_DEFLATED) as stream:
        stream.write(OUT / "reviewer" / "ceiling-review.json", "ceiling-review.json")
    with zipfile.ZipFile(review_archive) as stream:
        if stream.namelist() != ["ceiling-review.json"] or stream.testzip() is not None:
            raise RuntimeError("review-only archive boundary/CRC failed")
    (OUT / "pipeline-status.json").write_text(json.dumps({
        "state": "RAW_COMPLETE_REVIEW_PENDING",
        "ended_utc": datetime.now(timezone.utc).isoformat(),
        "review_items": 24,
        "blind_key_opened": False,
        "technical_interruption": "interruption-02.json",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    finalize_after_pipeline.main()
    (ROOT / "DELIVERY_STATUS.json").write_text(json.dumps({
        "status": "PASS", "measurement": "COMPLETE", "blind_review": "PENDING",
        "archives": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                     for name in ("ceiling-01.zip", "CEILING_BLIND_REVIEW_ONLY.zip")},
        "key_read": False, "reviewer_receives_only": "CEILING_BLIND_REVIEW_ONLY.zip",
    }, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        (OUT / "pipeline-status.json").write_text(json.dumps({
            "state": "PARTIAL", "error": f"{type(exc).__name__}: {exc}",
            "ended_utc": datetime.now(timezone.utc).isoformat(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        raise
