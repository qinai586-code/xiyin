"""Detached continuation for ceiling-01; evidence-only, never resamples an existing arm."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
PY = ROOT / ".venv" / "Scripts" / "python.exe"
LOGS = OUT / "logs"
MODEL_FILES = {
    "q8": (Path(r"D:\cuda\model\Qwen_Qwen3.5-4B-Q8_0.gguf"),
           "5c74c0ede371924357dff0cb6ba145bd67208b9b2389ded681adfff3f7608db7", 4622131168),
    "q9": (Path(r"D:\cuda\model\Qwen_Qwen3.5-9B-Q4_K_M.gguf"),
           "d784ce9eda1a5a7b51e8f705a9e6310844bf4f173654d115823c775fdea56d43", 6169341984),
}
LABELS = {
    "q4": ("q4b-q4", "q4b-q4-v4src", "q4b-q4-nomenu", "q4b-q4-preset", "q4b-q4-think"),
    "q8": ("q4b-q8", "q4b-q8-v4src"),
    "q9": ("q9b-q4", "q9b-q4-v4src", "q9b-q4-think"),
}
SOURCE_DIR = Path(r"C:\XIYIN\evidence\persona-v5-ff3fd30\retest_outputs\v5-run-01")


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def output_complete(label):
    path = OUT / f"probe-{label}.json"
    if not path.is_file():
        return False
    probe = json.loads(path.read_text(encoding="utf-8"))
    if probe.get("label") != label:
        raise RuntimeError(f"probe label mismatch: {path}")
    expected = 81 if "think" not in label else 9
    turns = probe.get("turns") or []
    if len(turns) != expected:
        raise RuntimeError(f"{label}: expected {expected} turns, got {len(turns)}")
    for turn in turns:
        samples = turn.get("samples") or []
        if len(samples) != 8 or [x.get("seed") for x in samples] != list(range(1000, 1008)):
            raise RuntimeError(f"{label}/{turn.get('key')}: sample count or seed mismatch")
        if any(x.get("error") for x in samples):
            raise RuntimeError(f"{label}/{turn.get('key')}: HTTP/sample error; no silent PASS")
    return True


def wait_for_phase(name, hours=5):
    deadline = time.monotonic() + hours * 3600
    while time.monotonic() < deadline:
        if all(output_complete(label) for label in LABELS[name]):
            with socket.socket() as probe:
                if probe.connect_ex(("127.0.0.1", 8080)) != 0:
                    return
        time.sleep(30)
    raise TimeoutError(f"{name} did not finish within {hours} hours")


def wait_for_download(name, hours=5):
    path, expected, total_bytes = MODEL_FILES[name]
    progress = path.with_name(path.name + ".progress")
    required_chunks = (total_bytes + 8388608 - 1) // 8388608
    deadline = time.monotonic() + hours * 3600
    while time.monotonic() < deadline:
        if path.is_file() and path.stat().st_size == total_bytes and progress.is_file():
            finished = {int(line) for line in progress.read_text(encoding="utf-8").splitlines()
                        if line.isdigit()}
            if finished == set(range(required_chunks)):
                actual = sha(path)
                if actual != expected:
                    raise RuntimeError(f"{name} model SHA mismatch after all chunks: {actual}")
                return
        time.sleep(30)
    raise TimeoutError(f"{name} download did not finish within {hours} hours")


def run(name, command):
    stdout = LOGS / f"pipeline-{name}.stdout.log"
    stderr = LOGS / f"pipeline-{name}.stderr.log"
    if stdout.exists() or stderr.exists():
        raise RuntimeError(f"refusing to overwrite {name} command evidence")
    with stdout.open("w", encoding="utf-8") as so, stderr.open("w", encoding="utf-8") as se:
        result = subprocess.run(command, cwd=ROOT, stdout=so, stderr=se,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    save(f"logs/pipeline-{name}.status.json", {
        "command": list(map(str, command)), "exit_code": result.returncode,
        "ended_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    if result.returncode:
        raise RuntimeError(f"{name} exit {result.returncode}; see {stderr}")


def blind_preflight():
    labels = ("q4b-q4", "q4b-q8", "q9b-q4")
    from importlib.util import module_from_spec, spec_from_file_location
    spec = spec_from_file_location("ceiling_probe", ROOT / "tools" / "ceiling_probe.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    for label in labels:
        probe = json.loads((OUT / f"probe-{label}.json").read_text(encoding="utf-8"))
        turns = {turn["key"]: turn for turn in probe["turns"]}
        for key in module.REVIEW_SUBSET:
            turn = turns[key]
            first = turn["samples"][:3]
            if len(first) != 3 or any(x.get("error") or not x.get("text", "").strip() for x in first):
                raise RuntimeError(f"blind first-3 sample gap: {label}/{key}; no silent replacement")


def main():
    save("pipeline-status.json", {"state": "RUNNING", "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    try:
        wait_for_phase("q4")
        for name in ("q8", "q9"):
            wait_for_download(name)
            run(name, [str(PY), "-B", "ceiling_outputs/run_ceiling.py", "--phase", name])
            wait_for_phase(name)
        # Raw probes and independent screen; the blind key is generated but never read here.
        probes = sorted(OUT.glob("probe-*.json"))
        run("screen", [str(PY), "-B", "tools/ceiling_probe.py", "screen",
                       *map(str, probes), "--out", str(OUT / "screen-all.json")])
        blind_preflight()
        run("blind", [str(PY), "-B", "tools/ceiling_probe.py", "blind",
                      str(OUT / "probe-q4b-q4.json"), str(OUT / "probe-q4b-q8.json"),
                      str(OUT / "probe-q9b-q4.json"), "--per-arm", "3", "--seed", "20260924",
                      "--review", str(OUT / "reviewer" / "ceiling-review.json"),
                      "--key", str(OUT / "keys" / "ceiling-key.json")])
        review = json.loads((OUT / "reviewer" / "ceiling-review.json").read_text(encoding="utf-8"))
        if len(review.get("items") or []) != 24 or any(len(x["candidates"]) != 10 for x in review["items"]):
            raise RuntimeError("blind packet is not exactly 24 x 10 candidates")
        save("pipeline-status.json", {"state": "RAW_COMPLETE_REVIEW_PENDING",
                                      "ended_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                      "review_items": 24, "blind_key_opened": False})
    except BaseException as exc:
        save("pipeline-status.json", {"state": "PARTIAL", "error": f"{type(exc).__name__}: {exc}",
                                      "ended_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
        raise


if __name__ == "__main__":
    main()
