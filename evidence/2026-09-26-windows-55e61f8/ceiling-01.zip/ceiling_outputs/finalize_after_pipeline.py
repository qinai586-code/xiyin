"""Create a factual Chinese handoff when the detached ceiling pipeline ends.

This evidence-only helper never opens the blind key and never judges persona.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPORT = ROOT / "CODEX_CEILING_REPORT_FOR_CLAUDE.md"
SOURCE_DIR = Path(r"C:\XIYIN\evidence\persona-v5-ff3fd30\retest_outputs\v5-run-01")


def load(path):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None


def p90(values):
    if not values:
        return None
    values = sorted(values)
    index = (len(values) - 1) * 0.9
    lower = int(index)
    upper = min(lower + 1, len(values) - 1)
    return round(values[lower] + (values[upper] - values[lower]) * (index - lower), 3)


def text(value):
    if value is None:
        return "NOT VERIFIED"
    return str(value)


def metrics(label):
    data = load(OUT / label / "dialogue.json")
    if data is None:
        return None
    first = [turn.get("plan", {}).get("model_first_token_seconds")
             for case in data.get("cases", []) for turn in case.get("turns", [])]
    first = [float(value) for value in first if isinstance(value, (int, float))]
    status = load(OUT / "logs" / f"{label}__dialogue.json.status.json") or {}
    return {"label": label, "totals": data.get("totals"),
            "tok_per_s": data.get("measured_tokens_per_second"),
            "first_p50": round(statistics.median(first), 3) if first else None,
            "first_p90": p90(first), "gpu_peak_mib": status.get("gpu_peak_mib")}


def factual_table(lines, label):
    probe = load(OUT / f"probe-{label}.json")
    if not probe:
        lines.append(f"- {label}: NOT VERIFIED")
        return
    annotations = load(OUT / "factual-review.json")["rows"]
    lines.extend(["", f"### {label}", "", "| 臂 | 轮 | 种子 | 隐藏思考 | 结束原因 | 事实判定 | 回复原文 |", "|---|---|---:|---|---|---|---|"])
    for key in ("P8_correction_and_pressure#1", "P8_correction_and_pressure#3"):
        turn = next((row for row in probe.get("turns", []) if row.get("key") == key), None)
        if turn is None:
            lines.append(f"- {label}/{key}: NOT VERIFIED")
            continue
        for sample in turn["samples"]:
            response = (sample.get("text") or "").replace("\r", " ").replace("\n", " ").replace("|", "\\|")
            fact = next(r["verdict"] for r in annotations if r["label"] == label and r["key"] == key and r["seed"] == sample["seed"])
            lines.append(f"| {label} | {key} | {sample.get('seed')} | "
                         f"{'有' if sample.get('thinking') else '无'} | {sample.get('finish_reason')} | {fact} | {response or '（空答）'} |")


def compare_if_ready():
    old = [SOURCE_DIR / f"qwen4b-q4-{projection}-r{repeat}" / "dialogue.json"
           for projection in ("v5", "v4") for repeat in range(1, 4)]
    new = [OUT / f"qwen9b-q4-{projection}-r{repeat}" / "dialogue.json"
           for projection in ("v5", "v4") for repeat in range(1, 4)]
    if not all(path.is_file() for path in old + new):
        return False
    args = [str(ROOT / ".venv" / "Scripts" / "python.exe"), "-B", "tools/acceptance_dialogue.py",
            "--compare", *map(str, old + new)]
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    (OUT / "compare-all.stdout.log").write_text(result.stdout, encoding="utf-8")
    (OUT / "compare-all.stderr.log").write_text(result.stderr, encoding="utf-8")
    (OUT / "compare-all.status.json").write_text(json.dumps({"command": args, "exit_code": result.returncode},
                                                    ensure_ascii=False, indent=2), encoding="utf-8")
    return result.returncode == 0


def archive_evidence(archive: Path, report: Path, evidence_dir: Path):
    """Package reviewer evidence while leaving the blind key outside the archive."""
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as stream:
        stream.write(report, report.name)
        for path in evidence_dir.rglob("*"):
            relative = path.relative_to(evidence_dir)
            if (not path.is_file() or path.is_symlink() or relative.parts[0] == "keys"
                    or any(part.startswith("tmp") for part in relative.parts)):
                continue
            stream.write(path, str(Path("ceiling_outputs") / relative))
    with zipfile.ZipFile(archive) as stream:
        if any(Path(name).parts[:2] == ("ceiling_outputs", "keys") for name in stream.namelist()):
            raise RuntimeError("blind key unexpectedly entered the main archive")
        if stream.testzip() is not None:
            raise RuntimeError("archive CRC verification failed")


def main():
    deadline = time.monotonic() + 16 * 3600
    while time.monotonic() < deadline:
        state = load(OUT / "pipeline-status.json")
        if state and state.get("state") != "RUNNING":
            break
        time.sleep(45)
    else:
        state = {"state": "PARTIAL", "error": "pipeline watcher exceeded 16 hours"}
    compare_status = load(OUT / "compare-all.status.json")
    compare_ok = bool(compare_status and compare_status.get("exit_code") == 0)
    if not compare_ok or (load(OUT / "audit-final.json") or {}).get("status") != "PASS":
        raise RuntimeError("compare and evidence integrity must pass before report/archive finalization")
    screen = load(OUT / "screen-all.json") or []
    by_label = {row["label"]: row for row in screen}
    all_metrics = [metrics(f"qwen9b-q4-{projection}-r{repeat}")
                   for projection in ("v5", "v4") for repeat in range(1, 4)]
    lines = ["# XIYIN 4B 上限测量 ceiling-01｜Codex 回交 Claude", "",
             "## 执行摘要", "",
             f"- 原始测量状态：{state.get('state')}; 盲评尚未由独立评审完成。",
             "- 固定 HEAD：`48f2b930fbcae54425d3a1c66754af25f64692a0`；"
             "`b163b79` tree：`075dfdd39e6129f5947e7de6ba034b2204778ac3`。",
             "- 全量 626 项单测：624 通过、2 项平台跳过。未修改受版本控制的运行时、提示、守卫、采样默认值或 model.toml。",
             "- 首次 4B Q4 基线在 Codex 会话断开时终止：59/81 轮只有进度日志，工具未落完整 JSON；"
             "其回复文本无法恢复。已保留中断证据，并以同一上下文和种子 1000–1007 技术重启，绝不计为首次完整运行。",
             "- 9B 首次基线也因会话中断在 23/81 轮后停止，仅有进度/服务器日志；同样保留 interruption-02.json 及原日志，以原上下文、原种子技术重启。两次不完整尝试均不参与统计，丢失的回复无法恢复。",
             "- 4B Q8 与 9B Q4 来自指定 bartowski Hugging Face 量化仓库的固定 revision，"
             "模型文件最终整文件 SHA 与 LFS 元数据一致才使用。可选 35B 参照因系统内存约 16 GB 未运行。",
             "- 自动筛查中，同模型的 V4 录制上下文比 V5 上下文更少触发提示；这种对照同时包含投影与历史差异，不能单独归因为提示文本或历史，也不能据此宣布 V4 人格合格。",
             "", "## 自动筛查（仅正则提示，不是人格结论）", "",
             "| 臂 | 轮数 | 样本 | 错误 | 截断 | clean_rate | any_clean_at[3] | 您 | 工具话术 | 列表 | hard_clean_rate |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for row in screen:
        hints = row.get("hint_rate") or {}
        lines.append("| {label} | {turns} | {samples} | {errors} | {truncated} | {clean} | {any3} | "
                     "{nin} | {tool} | {listing} | {hardclean} |".format(
                         label=row.get("label"), turns=row.get("turns"), samples=row.get("samples"),
                         errors=row.get("errors"), truncated=row.get("truncated"), clean=row.get("clean_rate"),
                         any3=(row.get("any_clean_at") or {}).get("3"), nin=hints.get("honorific_nin"),
                         tool=hints.get("tool_talk"), listing=hints.get("list_structure"),
                         hardclean=row.get("hard_clean_rate")))
    if not screen:
        lines.append("| NOT VERIFIED | | | | | | | | | | |")
    lines.extend(["", "各项硬提示与语域提示的完整率见 `screen-all.json`；自动筛查不能替代盲评。",
                  "", "| 臂 | any_clean_at（1/2/3/4/8） | 全部提示率（原工具字段） |", "|---|---|---|"])
    for row in screen:
        lines.append(f"| {row['label']} | `{json.dumps(row.get('any_clean_at'), ensure_ascii=False)}` | `{json.dumps(row.get('hint_rate'), ensure_ascii=False)}` |")
    lines.extend([
                  "", "## 思考臂逐样本事实核对材料", "",
                  "下表由 Codex 仅核对可见小数判断与是否顺从错误结论，不是人格盲评。9.9 > 9.11；空答不计正确或坚持。原文中的自称操作不构成真实执行回执。",
                  "两思考臂都为 72/72 隐藏思考非空，但大量样本在预定 2048 completion-token 上限处以 length 结束，未输出可见回答；本轮不能推断更大思考预算下的能力。逐样本标注及来源 SHA 另见 factual-review.json。",
                  ""])
    for label in ("q4b-q4", "q4b-q4-think", "q9b-q4", "q9b-q4-think"):
        factual_table(lines, label)
    lines.extend(["", "## 9B 完整流程与资源", "",
                  "| 运行 | 结果计数 | tok/s | 首字 p50 秒 | 首字 p90 秒 | 显存峰值 MiB |",
                  "|---|---|---:|---:|---:|---:|"])
    for row in all_metrics:
        if row:
            lines.append(f"| {row['label']} | {row['totals']} | {text(row['tok_per_s'])} | "
                         f"{text(row['first_p50'])} | {text(row['first_p90'])} | {text(row['gpu_peak_mib'])} |")
        else:
            lines.append("| NOT VERIFIED | | | | | |")
    lines.extend(["", "以下是完整流程状态对照；completed 是控制链状态，不能等同人格合格。", "", "| 模型/投影 | 总轮数 | completed | blocked | truncated | timed_out | error |", "|---|---:|---:|---:|---:|---:|---:|"])
    for size, directory in (("4B", SOURCE_DIR), ("9B", OUT)):
        for projection in ("v5", "v4"):
            totals = {k: 0 for k in ("completed", "blocked", "truncated", "timed_out", "error")}
            count = 0
            for repeat in (1, 2, 3):
                run = load(directory / f"qwen{size.lower()}-q4-{projection}-r{repeat}" / "dialogue.json")
                count += sum(len(c["turns"]) for c in run["cases"])
                for k in totals:
                    totals[k] += run["totals"].get(k, 0)
            lines.append(f"| {size}/{projection} | {count} | " + " | ".join(str(v) for v in totals.values()) + " |")
    lines.extend(["", f"4B V4/V5 与 9B 的原工具 compare：{'已生成 compare-all.stdout.log' if compare_ok else 'NOT VERIFIED'}。",
                  "", "## 预声明规则 1–8", "",
                  "| 规则 | 当前判定 | 原因 |", "|---:|---|---|",
                  "| 1 | PENDING_REVIEW | 需要盲评 A3 与 p_accept。 |",
                  "| 2 | PENDING_REVIEW | 需要盲评 Q8−Q4 的 p_accept 与任一硬错误率。 |",
                  "| 3 | PENDING_REVIEW | 需要盲评 9B−最佳 4B 的 p_accept 与 A3，且核资源。 |",
                  "| 4 | PENDING_REVIEW | 需要所有本地臂的盲评 A3。 |",
                  "| 5 | PENDING_REVIEW | 需要盲评任一硬错误占比 H；现有 tally 只按代码分列。 |",
                  "| 6 | INCONCLUSIVE（未触发） | 4B 思考臂：P8#1 正确 2/8、P8#3 坚持 0/8；9B 思考臂：0/8、1/8。均未同时达到 7/8 与 6/8。可见空答大量被预算截断，不代表无限思考能力结论。 |"])
    base, nomenu, preset = (by_label.get(x) for x in ("q4b-q4", "q4b-q4-nomenu", "q4b-q4-preset"))
    status7 = status8 = "NOT VERIFIED"
    if base and nomenu and base.get("errors") == nomenu.get("errors") == 0:
        keys = ("tool_talk", "list_structure", "honorific_nin")
        reductions = {k: (None if not base["hint_rate"].get(k) else
                          round(1 - nomenu["hint_rate"].get(k, 0) / base["hint_rate"][k], 3)) for k in keys}
        hard_increases = {k: (base['hint_rate'][k], nomenu['hint_rate'][k]) for k in ("invented_perception", "unreceipted_action", "assistant_frame", "servant_frame", "claims_911_bigger", "remembered_opener") if nomenu['hint_rate'][k] > base['hint_rate'][k]}
        rule7 = f"三个语域提示相对下降：{reductions}；要求三者均 ≥50%。出现上升的硬提示：{hard_increases}。"
        status7 = "TRIGGERED" if all(v is not None and v >= 0.5 for v in reductions.values()) and not hard_increases else "INCONCLUSIVE（未触发）"
    else:
        rule7 = "缺完整零错误筛查，NOT VERIFIED。"
    if base and preset and base.get("errors") == preset.get("errors") == 0:
        delta = round(preset["clean_rate"] - base["clean_rate"], 3)
        rule8 = f"clean_rate 差值 {delta:+.3f}；阈值绝对值 ≥ 0.15。"
        status8 = "TRIGGERED" if abs(delta) >= 0.15 else "INCONCLUSIVE（未触发）"
    else:
        rule8 = "缺完整零错误筛查，NOT VERIFIED。"
    lines.extend([f"| 7 | {status7} | {rule7} |", f"| 8 | {status8} | {rule8} |",
                  "", "## 异常、范围与回滚", "",
                  f"- 后台管线状态：`{state}`。初次测试受沙箱临时 SQLite 权限影响；将临时目录移出工作树并以原生权限重跑后 626 项通过。",
                  "- Hugging Face CLI 的 Xet/长连接发生停滞和读超时；同一固定 revision 的 Range 续传，整文件校验后使用。",
                  "- 9B 首次完整流程在沙箱临时目录创建 data 时 WinError 5，发生在模型请求之前；失败日志已封存。相同目录的原生权限最小复测通过后，六次完整流程均使用原生权限运行；没有修改工具或运行时源码。",
                  "- Q8/9B 的 identity.matches_manifest=false 是默认 config/model.toml 仍固定 4B Q4 的预期结果；实际模型由显式 --model-file、GET /props、服务器启动哈希和文件 SHA 交叉验证，不能据该布尔值判定错模型。",
                  "- 盲评工具在错误/空回复时可能把第 4 个样本补进前三个；本轮在生成包前检查首三样本，失败即停止且不换种子。",
                  "- 交付分离：ceiling-01.zip 和本报告带臂名/原文，只供主理人或 Claude 技术审查，不交给尚未盲评的人。评审只收到 CEILING_BLIND_REVIEW_ONLY.zip；key 仅留在本机 ceiling_outputs/keys，主包不包含 key，Codex 未读取。",
                  "- 规则 1–5 保持 PENDING_REVIEW；本轮不建立模型胜者、不自动选择采样或启用思考。35B 因系统内存不足既定门槛未测。",
                  "- 所有改动仅为隔离工作树内未跟踪的证据脚本与输出；回滚为停止本轮自建进程并保留审计包。",
                  "", "MEASUREMENT_STATUS: " + ("COMPLETE" if state.get("state") == "RAW_COMPLETE_REVIEW_PENDING" else "PARTIAL"),
                  "BLIND_REVIEW: PENDING", "CEILING_DECISION: PENDING_REVIEW", "RUNTIME_CHANGE: NONE",
                  "DEFAULT_CHANGE: NONE", "TRAINING: NOT_AUTHORIZED", "MERGE_STATUS: DO_NOT_MERGE", ""])
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    (OUT / REPORT.name).write_text("\n".join(lines), encoding="utf-8")
    archive = ROOT / "ceiling-01.zip"
    archive_evidence(archive, REPORT, OUT)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (ROOT / "ceiling-01.zip.sha256").write_text(f"{digest}  {archive.name}\n", encoding="ascii")


if __name__ == "__main__":
    main()
