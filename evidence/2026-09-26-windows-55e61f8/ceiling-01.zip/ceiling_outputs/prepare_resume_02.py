"""Preserve interrupted q9 evidence before a same-seed technical restart."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import socket
from datetime import datetime, timezone


OUT = Path(__file__).resolve().parent
LOGS = OUT / "logs"
ARCHIVE = LOGS / "interrupted-02"
SOURCES = (
    "pipeline-q9.stdout.log",
    "pipeline-q9.stderr.log",
    "probe-q9b-q4.json.log",
    "probe-q9b-q4.json.gpu.jsonl",
    "server-q9-default.stdout.log",
    "server-q9-default.stderr.log",
    "server-q9-default.json",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    if ARCHIVE.exists() or (OUT / "interruption-02.json").exists():
        raise RuntimeError("resume-02 already prepared")
    if (OUT / "probe-q9b-q4.json").exists():
        raise RuntimeError("q9 baseline result already exists; no resample")
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", 8080)) == 0:
            raise RuntimeError("port 8080 is active; do not disturb the server")
    root = OUT.parent.resolve()
    if not ARCHIVE.resolve().is_relative_to(root):
        raise RuntimeError("archive escapes worktree")
    files = []
    for name in SOURCES:
        src = LOGS / name
        dst = ARCHIVE / name
        if not src.is_file() or src.is_symlink() or not src.resolve().is_relative_to(root):
            raise RuntimeError(f"missing or unsafe source: {name}")
        if not dst.resolve().is_relative_to(root):
            raise RuntimeError(f"unsafe destination: {name}")
        files.append({"name": name, "bytes": src.stat().st_size, "sha256": sha(src)})
    ARCHIVE.mkdir(parents=False, exist_ok=False)
    for name in SOURCES:
        shutil.move(str(LOGS / name), str(ARCHIVE / name))
    status = OUT / "pipeline-status.json"
    shutil.copy2(status, OUT / "pipeline-status.interrupted-02.json")
    record = {
        "state": "TECHNICAL_INTERRUPTION",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "reason": "session transition stopped detached q9 and watcher processes",
        "q9_completed_json": False,
        "restart_context": "same V5 recorded context, seeds 1000-1007, 8 samples per turn",
        "partial_outputs_not_counted": True,
        "preserved_files": files,
    }
    (OUT / "interruption-02.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
