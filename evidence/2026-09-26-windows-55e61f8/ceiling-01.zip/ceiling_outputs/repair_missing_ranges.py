"""Fill only missing 8 MiB GGUF chunks using 1 MiB official HTTP ranges.

The pinned size and SHA-256 are checked before a model can enter measurement.
Existing completed chunks are never re-fetched or overwritten.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import time
import urllib.request

MODELS = {
    "q8": ("bartowski/Qwen_Qwen3.5-4B-GGUF", "4168f45a16a1290d65a4ec0fa312ae917a4c15d6",
           "Qwen_Qwen3.5-4B-Q8_0.gguf", 4622131168,
           "5c74c0ede371924357dff0cb6ba145bd67208b9b2389ded681adfff3f7608db7"),
    "q9": ("bartowski/Qwen_Qwen3.5-9B-GGUF", "182be2fd6c7bc44887d88a91cb03ff009cc9f549",
           "Qwen_Qwen3.5-9B-Q4_K_M.gguf", 6169341984,
           "d784ce9eda1a5a7b51e8f705a9e6310844bf4f173654d115823c775fdea56d43"),
}
CHUNK = 8388608
SUBCHUNK = 1048576


def fetch(url, lo, hi, total):
    request = urllib.request.Request(url, headers={"Range": f"bytes={lo}-{hi}",
                                                   "Accept-Encoding": "identity"})
    for attempt in range(1, 6):
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                expected_range = f"bytes {lo}-{hi}/{total}"
                if response.status != 206 or response.headers.get("Content-Range") != expected_range:
                    raise IOError("wrong HTTP status or Content-Range")
                data = response.read()
            if len(data) != hi - lo + 1:
                raise IOError(f"short range {len(data)}/{hi-lo+1}")
            return data
        except Exception as exc:
            if attempt == 5:
                raise
            print(f"retry bytes={lo}-{hi} attempt={attempt} reason={type(exc).__name__}", flush=True)
            time.sleep(2 * attempt)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=tuple(MODELS))
    args = parser.parse_args()
    repo, revision, filename, total, expected_sha = MODELS[args.model]
    target = Path(r"D:\cuda\model") / filename
    progress = Path(str(target) + ".progress")
    if not target.is_file() or target.stat().st_size != total or not progress.is_file():
        raise RuntimeError("target size or progress file does not match pinned model")
    count = (total + CHUNK - 1) // CHUNK
    done = {int(line) for line in progress.read_text(encoding="utf-8").splitlines() if line.isdigit()}
    if not done <= set(range(count)):
        raise RuntimeError("progress contains an out-of-range chunk")
    missing = sorted(set(range(count)) - done)
    print(f"model={args.model} completed={len(done)}/{count} missing={missing}", flush=True)
    url = f"https://huggingface.co/{repo}/resolve/{revision}/{filename}"
    with target.open("r+b") as stream:
        for index in missing:
            start = index * CHUNK
            end = min(start + CHUNK, total)
            for lo in range(start, end, SUBCHUNK):
                hi = min(lo + SUBCHUNK, end) - 1
                data = fetch(url, lo, hi, total)
                stream.seek(lo)
                stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            with progress.open("a", encoding="utf-8") as journal:
                journal.write(f"{index}\n")
                journal.flush()
                os.fsync(journal.fileno())
            print(f"completed_chunk={index}", flush=True)
    with target.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    print(f"size={target.stat().st_size} sha256={actual} expected={expected_sha} hash_ok={actual == expected_sha}", flush=True)
    return 0 if actual == expected_sha else 4


if __name__ == "__main__":
    raise SystemExit(main())
