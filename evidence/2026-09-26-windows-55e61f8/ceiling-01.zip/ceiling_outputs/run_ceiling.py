"""Evidence-only local runner for the pinned ceiling-01 measurement arms.

This file lives in the untracked evidence directory. It does not change XIYIN
runtime code or configuration. Each phase is one-shot: existing arm outputs
cause a stop rather than an unrecorded resample.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
from urllib.request import urlopen

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SERVER = Path(r"D:\cuda\bin\llama-server.exe")
MODELS = {
    "q4": Path(r"D:\cuda\model\Qwen_Qwen3.5-4B-Q4_K_M.gguf"),
    "q8": Path(r"D:\cuda\model\Qwen_Qwen3.5-4B-Q8_0.gguf"),
    "q9": Path(r"D:\cuda\model\Qwen_Qwen3.5-9B-Q4_K_M.gguf"),
}
EXPECTED_SHA256 = {
    "q4": "13c16f426047e2de38cd075bdade4a7bcbc8c774384876f677740cda65f8a983",
    "q8": "5c74c0ede371924357dff0cb6ba145bd67208b9b2389ded681adfff3f7608db7",
    "q9": "d784ce9eda1a5a7b51e8f705a9e6310844bf4f173654d115823c775fdea56d43",
}
SOURCE_DIR = Path(r"C:\XIYIN\evidence\persona-v5-ff3fd30\retest_outputs\v5-run-01")
SRC5 = SOURCE_DIR / "qwen4b-q4-v5-r1" / "dialogue.json"
SRC4 = SOURCE_DIR / "qwen4b-q4-v4-r1" / "dialogue.json"
FACT = ["P8_correction_and_pressure", "P4_agreement_and_praise#1",
        "P4_agreement_and_praise#2", "P7_help_vs_share#5", "F1_stage_direction#5"]
PY = sys.executable


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def gpu_sample() -> dict:
    result = subprocess.run(["nvidia-smi", "--query-gpu=memory.used,memory.free,utilization.gpu",
                             "--format=csv,noheader,nounits"], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", timeout=12)
    return {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "raw": result.stdout.strip(), "exit_code": result.returncode}


def run_command(name: str, args: list[str], env: dict) -> None:
    target = OUT / name
    if target.exists():
        raise RuntimeError(f"Refusing to resample existing output: {target}")
    log_name = name.replace("/", "__").replace("\\", "__")
    log = OUT / "logs" / f"{log_name}.log"
    status = OUT / "logs" / f"{log_name}.status.json"
    gpu_log = OUT / "logs" / f"{log_name}.gpu.jsonl"
    if log.exists() or status.exists() or gpu_log.exists():
        raise RuntimeError(f"Refusing to overwrite existing evidence for {name}")
    record = {"command": args, "cwd": str(ROOT), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "gpu_idle": gpu_sample(), "output": str(target)}
    stop = threading.Event()

    def monitor():
        with gpu_log.open("w", encoding="utf-8") as stream:
            while not stop.is_set():
                try:
                    stream.write(json.dumps(gpu_sample()) + "\n")
                    stream.flush()
                except (OSError, subprocess.SubprocessError) as exc:
                    stream.write(json.dumps({"error": type(exc).__name__}) + "\n")
                    stream.flush()
                stop.wait(2)

    worker = threading.Thread(target=monitor, daemon=True)
    worker.start()
    try:
        with log.open("w", encoding="utf-8") as stream:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        record["exit_code"] = result.returncode
    finally:
        stop.set()
        worker.join(timeout=15)
        record["ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        used = []
        for line in gpu_log.read_text(encoding="utf-8").splitlines():
            item = json.loads(line)
            try:
                used.append(int(item["raw"].split(",")[0].strip()))
            except (KeyError, ValueError):
                pass
        record["gpu_peak_mib"] = max(used) if used else None
        record["output_exists"] = target.exists()
        save(status, record)
    if record.get("exit_code") != 0 or not target.is_file():
        raise RuntimeError(f"{name} failed; see {status} and {log}")
    print(f"DONE {name} peak={record['gpu_peak_mib']} MiB", flush=True)


class LocalServer:
    def __init__(self, model: Path, phase: str, *, template_default: bool = True):
        self.model = model
        self.phase = phase
        self.template_default = template_default
        self.child = None

    def __enter__(self):
        with socket.socket() as probe:
            if probe.connect_ex(("127.0.0.1", 8080)) == 0:
                raise RuntimeError("Port 8080 already occupied; refusing to disturb another service")
        flags = [str(SERVER), "--model", str(self.model), "--host", "127.0.0.1", "--port", "8080",
                 "--alias", "xiyin", "--ctx-size", "4096", "--parallel", "1", "--n-gpu-layers", "999",
                 "--jinja"]
        if self.template_default:
            flags.extend(["--chat-template-kwargs", '{"enable_thinking":false}'])
        flags.append("--no-mmproj-auto")
        suffix = "default" if self.template_default else "thinking-retry"
        stem = f"server-{self.phase}-{suffix}"
        stdout = (OUT / "logs" / f"{stem}.stdout.log").open("w", encoding="utf-8")
        stderr = (OUT / "logs" / f"{stem}.stderr.log").open("w", encoding="utf-8")
        try:
            self.child = subprocess.Popen(flags, cwd=ROOT, stdout=stdout, stderr=stderr,
                                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        finally:
            stdout.close()
            stderr.close()
        for _ in range(180):
            if self.child.poll() is not None:
                raise RuntimeError(f"Server exited {self.child.returncode}; inspect {stem}.stderr.log")
            try:
                with urlopen("http://127.0.0.1:8080/props", timeout=2) as response:
                    props = json.load(response)
                break
            except Exception:
                time.sleep(1)
        else:
            raise TimeoutError("Server did not become ready in 180 seconds")
        save(OUT / "logs" / f"{stem}.json", {
            "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "pid": self.child.pid, "flags": flags, "model_sha256": sha(self.model),
            "model_bytes": self.model.stat().st_size, "server_sha256": sha(SERVER),
            "props": props, "gpu_idle": gpu_sample()})
        print(f"SERVER {self.phase} pid={self.child.pid}", flush=True)
        return self

    def __exit__(self, *_):
        if self.child and self.child.poll() is None:
            self.child.terminate()
            try:
                self.child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.child.kill()
                self.child.wait(timeout=15)
        time.sleep(2)


def replay(label: str, source: Path, model: Path, env: dict, *extra: str) -> None:
    name = f"probe-{label}.json"
    args = [PY, "-B", "tools/ceiling_probe.py", "replay", "--report", str(source),
            "--label", label, "--samples", "8", "--seed", "1000", *extra,
            "--model-file", str(model), "--out", str(OUT / name)]
    run_command(name, args, env)


def thinking_missing(label: str) -> bool:
    probe = json.loads((OUT / f"probe-{label}.json").read_text(encoding="utf-8"))
    samples = [sample for turn in probe["turns"] for sample in turn["samples"]]
    return bool(samples) and all(not sample.get("thinking") for sample in samples)


def phase(name: str):
    model = MODELS[name]
    if not model.is_file():
        raise FileNotFoundError(model)
    actual_sha = sha(model)
    if actual_sha != EXPECTED_SHA256[name]:
        raise RuntimeError(f"Model SHA-256 mismatch for {name}: {actual_sha}")
    temp = Path(r"C:\XIYIN\evidence\ceiling-01-test-temp")
    temp.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, TEMP=str(temp), TMP=str(temp), PYTHONUTF8="1",
               PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    with LocalServer(model, name):
        if name == "q4":
            replay("q4b-q4", SRC5, model, env)
            replay("q4b-q4-v4src", SRC4, model, env)
            replay("q4b-q4-nomenu", SRC5, model, env, "--ablate", "tool_menu")
            replay("q4b-q4-preset", SRC5, model, env, "--sampling-file",
                   "config/sampling/qwen3.5-nonthinking.candidate.json")
            replay("q4b-q4-think", SRC5, model, env, "--thinking", "--cases", *FACT)
        elif name == "q8":
            replay("q4b-q8", SRC5, model, env)
            replay("q4b-q8-v4src", SRC4, model, env)
        else:
            replay("q9b-q4", SRC5, model, env)
            replay("q9b-q4-v4src", SRC4, model, env)
            replay("q9b-q4-think", SRC5, model, env, "--thinking", "--cases", *FACT)
    if name in ("q4", "q9"):
        label = "q4b-q4-think" if name == "q4" else "q9b-q4-think"
        if thinking_missing(label):
            original = OUT / f"probe-{label}.json"
            original.rename(OUT / f"probe-{label}-first.json")
            (OUT / "logs" / f"probe-{label}.json.status.json").rename(
                OUT / "logs" / f"probe-{label}-first.json.status.json")
            (OUT / "logs" / f"probe-{label}.json.log").rename(
                OUT / "logs" / f"probe-{label}-first.json.log")
            (OUT / "logs" / f"probe-{label}.json.gpu.jsonl").rename(
                OUT / "logs" / f"probe-{label}-first.json.gpu.jsonl")
            with LocalServer(model, name, template_default=False):
                replay(label, SRC5, model, env, "--thinking", "--cases", *FACT)
    if name == "q9":
        with LocalServer(model, "q9-full"):
            for projection in ("v5", "v4"):
                for repeat in range(1, 4):
                    label = f"qwen9b-q4-{projection}-r{repeat}"
                    dest = OUT / label
                    dest.mkdir(exist_ok=False)
                    run_command(f"{label}/dialogue.json", [PY, "-B", "tools/acceptance_dialogue.py",
                                "--label", label, "--persona-projection", projection,
                                "--model-file", str(model), "--out", str(dest / "dialogue.json")], env)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=tuple(MODELS), required=True)
    args = parser.parse_args()
    phase(args.phase)
