"""Resume only the six missing 9B full runs after a native temp ACL check."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil

import run_ceiling as base


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
FAILED = OUT / "logs" / "failed-temp-01"
FAILED_FILES = (
    "qwen9b-q4-v5-r1__dialogue.json.log",
    "qwen9b-q4-v5-r1__dialogue.json.status.json",
    "qwen9b-q4-v5-r1__dialogue.json.gpu.jsonl",
)


def preserve_failed_attempt() -> None:
    if FAILED.exists():
        raise RuntimeError("failed-temp-01 already preserved")
    if (OUT / "qwen9b-q4-v5-r1" / "dialogue.json").exists():
        raise RuntimeError("v5-r1 already has a result; do not resample")
    worktree = ROOT.resolve()
    rows = []
    for name in FAILED_FILES:
        src = OUT / "logs" / name
        dst = FAILED / name
        if not src.is_file() or src.is_symlink() or not src.resolve().is_relative_to(worktree):
            raise RuntimeError(f"missing or unsafe failed log: {name}")
        if not dst.resolve().is_relative_to(worktree):
            raise RuntimeError(f"unsafe destination: {name}")
        rows.append({"file": name, "sha256": hashlib.sha256(src.read_bytes()).hexdigest()})
    FAILED.mkdir(exist_ok=False)
    for name in FAILED_FILES:
        shutil.move(str(OUT / "logs" / name), str(FAILED / name))
    (OUT / "temp-permission-retest.json").write_text(json.dumps({
        "red": "failed-temp-01/qwen9b-q4-v5-r1__dialogue.json.log: WinError 5 in sandbox temp",
        "green": "native Windows command created and removed data child in same TEMP; exit 0",
        "runtime_source_changed": False,
        "failed_attempt_result_json": False,
        "failed_files": rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    model = base.MODELS["q9"]
    if base.sha(model) != base.EXPECTED_SHA256["q9"]:
        raise RuntimeError("9B model hash drift")
    temp = Path(r"C:\XIYIN\evidence\ceiling-01-test-temp")
    if not temp.is_dir():
        raise RuntimeError("tested TEMP missing")
    preserve_failed_attempt()
    env = dict(os.environ, TEMP=str(temp), TMP=str(temp), PYTHONUTF8="1",
               PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    with base.LocalServer(model, "q9full-native"):
        for projection in ("v5", "v4"):
            for repeat in (1, 2, 3):
                label = f"qwen9b-q4-{projection}-r{repeat}"
                dest = OUT / label
                if dest.exists():
                    if label != "qwen9b-q4-v5-r1" or any(dest.iterdir()):
                        raise RuntimeError(f"refusing to resample existing {label}")
                else:
                    dest.mkdir(exist_ok=False)
                base.run_command(f"{label}/dialogue.json", [base.PY, "-B", "tools/acceptance_dialogue.py",
                                 "--label", label, "--persona-projection", projection,
                                 "--model-file", str(model), "--out", str(dest / "dialogue.json")], env)


if __name__ == "__main__":
    main()
