"""Synthetic check that the blind key remains outside the reviewer archive."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from tempfile import TemporaryDirectory
import zipfile

tool = Path(__file__).with_name("finalize_after_pipeline.py")
spec = spec_from_file_location("finalize_after_pipeline", tool)
module = module_from_spec(spec)
spec.loader.exec_module(module)

with TemporaryDirectory(dir=Path(__file__).parent) as temporary:
    base = Path(temporary)
    evidence = base / "ceiling_outputs"
    (evidence / "keys").mkdir(parents=True)
    (evidence / "reviewer").mkdir()
    (evidence / "keys" / "ceiling-key.json").write_text("SYNTHETIC_SECRET", encoding="utf-8")
    (evidence / "reviewer" / "ceiling-review.json").write_text("SYNTHETIC_REVIEW", encoding="utf-8")
    report = base / "report.md"
    report.write_text("SYNTHETIC_REPORT", encoding="utf-8")
    archive = base / "test.zip"
    module.archive_evidence(archive, report, evidence)
    with zipfile.ZipFile(archive) as stream:
        names = stream.namelist()
        assert "ceiling_outputs/reviewer/ceiling-review.json" in names
        assert "report.md" in names
        assert not any("keys" in Path(name).parts for name in names)
        assert b"SYNTHETIC_SECRET" not in b"".join(stream.read(name) for name in names)
    assert (evidence / "keys" / "ceiling-key.json").read_text(encoding="utf-8") == "SYNTHETIC_SECRET"
print("PASS: key excluded; reviewer packet and report retained; key untouched")
