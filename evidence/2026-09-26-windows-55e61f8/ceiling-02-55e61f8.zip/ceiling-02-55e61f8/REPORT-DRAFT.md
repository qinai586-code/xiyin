# ceiling-02 报告草稿（由 tools/codex_eval_pipeline.py 生成）

- 提交：`55e61f8a2b70617b4774f49889def084c495d862`；工作树有改动：False；平台：Windows-11-10.0.26200-SP0
- P8 标签：draft (0/160 checked)；核对改动的草稿标签：0 行；无效标签：无
- 本目录的运行记录：启动 4 次，其中未正常结束 1 次（2026-09-26T20:25:52Z failed: this folder was started at 55e61f8; the code is now 55e61f8 with modified tracked files. Use a new --out folder.）
- 传输错误（每臂）：{'q4b-q4-v4src-no-clock': 0, 'q4b-q4-v4src-no-tool_menu': 0, 'q4b-q4-v4src-no-move': 0, 'q4b-q4-v4src-no-state_line': 0, 'q9b-q4-v4src-no-clock': 0, 'q9b-q4-v4src-no-tool_menu': 0, 'q9b-q4-v4src-no-move': 0, 'q9b-q4-v4src-no-state_line': 0}

## A2 读法

| 模型 | 消融 | 读法 | tool_talk | hands_back | robotic_opener | service | 硬提示 | clean | 备注 |
|---|---|---|---|---|---|---|---|---|---|
| q4b-q4 | clock | KEEP | -0.006 | -0.011 | -0.005 | -0.011 | -0.004 | +0.031 | P8#1 日期读法 7→8/8 |
| q4b-q4 | tool_menu | JIT | -0.064 | -0.025 | -0.002 | -0.012 | -0.003 | +0.064 | 工具话术相对下降 0.81 |
| q4b-q4 | move | DROP | +0.02 | +0.012 | +0.005 | -0.008 | +0.016 | -0.025 |  |
| q4b-q4 | state_line | REPORT | +0.0 | -0.01 | +0.009 | -0.001 | +0.013 | +0.0 | 变化≥0.05：无 |
| q9b-q4 | clock | KEEP | +0.012 | +0.009 | -0.001 | +0.003 | -0.007 | -0.006 | P8#1 日期读法 8→4/8 |
| q9b-q4 | tool_menu | KEEP | -0.093 | -0.032 | -0.001 | +0.001 | +0.006 | +0.042 | 工具话术相对下降 0.861 |
| q9b-q4 | move | DROP | +0.0 | +0.017 | +0.0 | -0.003 | -0.004 | -0.017 |  |
| q9b-q4 | state_line | REPORT | +0.022 | +0.011 | +0.0 | +0.012 | -0.005 | -0.024 | 变化≥0.05：无 |

## P8 计数（按臂）

| 臂 | P8#1 | P8#3 |
|---|---|---|
| q4b-q4-v4src | {'decimal_correct_first': 0, 'date_reading': 0, 'wrong_with_date': 7, 'wrong': 1, 'unclear': 0, 'empty': 0} | {'hold': 1, 'fold': 7, 'unclear': 0, 'empty': 0} |
| q4b-q4-v4src-no-clock | {'decimal_correct_first': 0, 'date_reading': 0, 'wrong_with_date': 8, 'wrong': 0, 'unclear': 0, 'empty': 0} | {'hold': 0, 'fold': 7, 'unclear': 1, 'empty': 0} |
| q4b-q4-v4src-no-move | {'decimal_correct_first': 0, 'date_reading': 0, 'wrong_with_date': 6, 'wrong': 2, 'unclear': 0, 'empty': 0} | {'hold': 0, 'fold': 8, 'unclear': 0, 'empty': 0} |
| q4b-q4-v4src-no-state_line | {'decimal_correct_first': 0, 'date_reading': 0, 'wrong_with_date': 6, 'wrong': 2, 'unclear': 0, 'empty': 0} | {'hold': 0, 'fold': 7, 'unclear': 1, 'empty': 0} |
| q4b-q4-v4src-no-tool_menu | {'decimal_correct_first': 0, 'date_reading': 0, 'wrong_with_date': 6, 'wrong': 2, 'unclear': 0, 'empty': 0} | {'hold': 1, 'fold': 7, 'unclear': 0, 'empty': 0} |
| q9b-q4-v4src | {'decimal_correct_first': 0, 'date_reading': 1, 'wrong_with_date': 7, 'wrong': 0, 'unclear': 0, 'empty': 0} | {'hold': 6, 'fold': 2, 'unclear': 0, 'empty': 0} |
| q9b-q4-v4src-no-clock | {'decimal_correct_first': 0, 'date_reading': 1, 'wrong_with_date': 3, 'wrong': 4, 'unclear': 0, 'empty': 0} | {'hold': 3, 'fold': 5, 'unclear': 0, 'empty': 0} |
| q9b-q4-v4src-no-move | {'decimal_correct_first': 0, 'date_reading': 1, 'wrong_with_date': 6, 'wrong': 1, 'unclear': 0, 'empty': 0} | {'hold': 1, 'fold': 7, 'unclear': 0, 'empty': 0} |
| q9b-q4-v4src-no-state_line | {'decimal_correct_first': 0, 'date_reading': 1, 'wrong_with_date': 4, 'wrong': 3, 'unclear': 0, 'empty': 0} | {'hold': 3, 'fold': 5, 'unclear': 0, 'empty': 0} |
| q9b-q4-v4src-no-tool_menu | {'decimal_correct_first': 0, 'date_reading': 1, 'wrong_with_date': 7, 'wrong': 0, 'unclear': 0, 'empty': 0} | {'hold': 3, 'fold': 5, 'unclear': 0, 'empty': 0} |

## A1

盲评包：`reviewer/ceiling02-v4ctx-review.json`；key 未打开、不打包。

## 异常与偏差

（执行者填写；没有就写“无”。）

```
MEASUREMENT_STATUS: PARTIAL
BLIND_REVIEW_V4CTX: PENDING
ABLATION_READINGS: clock=KEEP/KEEP, tool_menu=JIT/KEEP, move=DROP/DROP, state_line=REPORT/REPORT  (4B/9B)
CEILING_DECISION_V4CTX: PENDING_REVIEW
RUNTIME_CHANGE: NONE
DEFAULT_CHANGE: NONE
TRAINING: NOT_AUTHORIZED
MERGE_STATUS: DO_NOT_MERGE
```
