# phase-b-01 报告草稿（由 tools/codex_eval_pipeline.py 生成）

- 提交：`55e61f8a2b70617b4774f49889def084c495d862`；工作树有改动：False；平台：Windows-11-10.0.26200-SP0
- 运行：12/12；报告里的代码版本数：1（应为 1）
- 被拦候选：48；已判定 0；无效判定：无
- 本目录的运行记录：启动 4 次，其中未正常结束 3 次（2026-09-26T19:48:11Z failed: unit tests failed; see C:\XIYIN\evidence\results-55e61f8\phase-b-01-55e61f8\unit-tests-FAILED.json; 2026-09-26T20:21:45Z failed: unit tests failed; see C:\XIYIN\evidence\results-55e61f8\phase-b-01-55e61f8\unit-tests-FAILED.json; 2026-09-26T20:25:52Z failed: this folder was started at 55e61f8; the code is now 55e61f8 with modified tracked files. Use a new --out folder.）
- 重跑过的运行（技术中断后）：无

## 按臂汇总

| 臂 | 轮数 | 状态 | 弃答率 | 重试 | 重试成功率 | 放出前外流 | 复检违规轮 | 违规类别（候选） | 生成秒 中位/P90 | 核验秒 中位/P90 | 首字秒 中位/P90 | 字数 中位/P90 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| pb-4b-v4-hold | 243 | {'completed': 238, 'truncated': 4, 'abstained': 1} | 0.004 | 16 | 0.938 | 0 | 0  | {'guard': 7, 'protocol': 1, 'activity': 1, 'operation': 3, 'attribution': 1, 'numeric': 4, 'record': 1} | 1.406/2.734 | 0.0/0.0 | 1.438/3.078 | 185/410 |
| pb-4b-v4-open | 243 | {'completed': 222, 'blocked': 15, 'truncated': 6} | 0.0 | 0 | None | — | 5 {'operation': 3, 'numeric': 1, 'protocol': 1} | — | 1.516/3.031 | None/None | 0.578/1.031 | 200/457 |
| pb-9b-v4-hold | 243 | {'completed': 230, 'abstained': 8, 'truncated': 5} | 0.033 | 23 | 0.652 | 0 | 0  | {'protocol': 2, 'guard': 22, 'operation': 2, 'numeric': 5, 'record': 1, 'identity_frame': 2} | 1.937/4.047 | 0.0/0.0 | 2.156/5.219 | 178/453 |
| pb-9b-v4-open | 243 | {'completed': 224, 'blocked': 16, 'truncated': 3} | 0.0 | 0 | None | — | 9 {'protocol': 1, 'operation': 4, 'identity_frame': 1, 'numeric': 3, 'record': 1, 'third_party': 1} | — | 2.0/3.922 | None/None | 0.688/1.11 | 167/417 |

不开核验的臂里，“复检违规轮”就是“如果没有核验会放出多少违规”的对照。首次出声时间：NOT_MEASURED（测试框架没有接声音）。

## 异常与偏差

（执行者填写；没有就写“无”。）

```
PHASE_B_VALIDATION: PARTIAL
NO_RELEASE_BEFORE_VERIFY: PASS
RELEASED_CLOSED_CLASS_VIOLATIONS: 0
FALSE_POSITIVE_RATE: PENDING (0/48 judged)
ABSTENTION_RATE_4B/9B: 0.4%/3.3%
DEFAULT_CHANGE: NONE
TRAINING: NOT_AUTHORIZED
MERGE_STATUS: DO_NOT_MERGE
```
