# CODEX V5 Ablation Report for Claude

Date: 2026-09-24

## 中文摘要

新工作树已整合 Claude 固定分支与前次 Codex 补丁；最终单测 617 项，615 通过、2 跳过。候选数据工具的两个确定性边界缺陷已最小修复。六轮真实 4B 对照原文、自动审计和三组盲包见下。因额度保留，A–T 全量独立语义评审未完成；证据索引不能代替人格验收。未合并、推送、部署或训练。

## Scope and tested state

Workspace: `C:\XIYIN\evidence\persona-v5-ff3fd30`

Upstream: `ff3fd30beb47b34c7e8508dbcf70c6d293f5a47c`; initial integration: `a039f3e40460f01a845fc177076d9d00f4c2af6c`; final tested local commit: `aa42b67c2f088e7893d855c6198dce21a0192931`; tree: `075dfdd39e6129f5947e7de6ba034b2204778ac3`.

Incoming Codex patch SHA-256: `844d93e8eb5cd52989eb2b78dfa76dde6b03d947115359be40cf8eb707dbd442`. Applied without conflict. Local commits only. Full changed-file hashes and exported patch hashes: `tested-state.json`.

Environment: Windows, Python 3.12.10; new venv reads the prior tested pure-Python site-packages through one .pth file. Existing environment was not modified. GPU: RTX 5070 Ti Laptop, 12227 MiB. Model: D:/cuda/model/Qwen_Qwen3.5-4B-Q4_K_M.gguf; SHA-256 13c16f426047e2de38cd075bdade4a7bcbc8c774384876f677740cda65f8a983. llama.cpp b11062-3cf03257f; server SHA-256 55c40cebb08cb596247c379328c58b9b2539b50e1e52089fb957010500eadffb. Both binary/model hashes match prior final 4B runs. No 9B or sampling changes.

## Integration, failure history, and repairs

Command: `.venv/Scripts/python.exe -B -W error -m unittest discover -s tests`. The first sandbox run failed because Windows temporary directories were inaccessible (WinError 5 / SQLite open errors). It is retained in unit-tests-integration.log. No assertions were relaxed. Native-permission rerun with TEMP/TMP scoped to C:/XIYIN/evidence/v5-temp-20260924 passed: 613 tests, 2 skips. After the two bounded fixes, unit-tests-final.log records 617 tests, 2 skips, zero failures/errors. Native tests are not evidence of Linux/3.13 verification.

Two deterministic candidate-tool defects reproduced before fixing: (1) an invalid explicit XIYIN_DATA_ROOT was silently ignored; (2) a linked store file could alias another file outside the store. Added tests/test_candidate_data_windows_review.py and minimally modified tools/candidate_data.py. Red log: candidate-boundary-red.log (2 failures, 2 legitimate neighbors pass). Green: bounded-fixes-green.log (26 tests pass). Native full regression passes. The tool now rejects invalid explicit roots and non-independent storage files before store creation/use. This is a single-writer offline check, not race-resistant filesystem isolation.

Exact diffs: incoming-repair.patch (previous work), integration.patch (applied integration), local-fixes.patch (two new fixes), combined-local.patch (all Codex changes vs ff3fd30). No persona prompt rule, guard threshold, default projection, seed, tool menu, R2 or R3 implementation was changed by Codex.

## Independent static review

| Claim / defect | Status | Evidence / limitation |

|---|---|---|

| V1–V4 projection bytes unchanged; default V3; seed unchanged | REPRODUCED | static-review.json compares current projections with prior worktree and verifies seed |

| V5 removes declared rule bundle; no new move line; directive stays last | REPRODUCED for inspected code and tests | Claude diff and test_persona_projection_v5; actual run hashes/audit below |

| Evidence fields survive, including other record kinds and public scope | REPRODUCED for enumerated fixtures | static-review.json extra_record_types; original V5 tests. Ledger completeness remains scoped, not global |

| Private echo blocked; sayable self-facts allowed; explicit length/creative requests preserved | REPRODUCED in synthetic tests | V5 suite and full regression; paraphrase safety still requires semantic review |

| Invalid explicit data-root override refused | REPRODUCED DEFECT, FIXED | Red/green logs and local-fixes.patch |

| Store linked-file alias refused | REPRODUCED DEFECT, FIXED | Real file hardlink fixture red/green; no real production targets |

| Repository mixed-case and junction aliases rejected | REPRODUCED | static-review.json; actual Windows junction fixture, no write through it |

| RAW_CANDIDATE only, UTF-8 JSONL, content-free tombstone schema | REPRODUCED in synthetic tests | Original candidate suite + added UTF-8 test; real store init/status only, no owner judgments ingested |

| No network/training imports | REPRODUCED by inspection/tests | AST import inventory in static-review.json; no training pipeline run |

| Every semantic paraphrase classified as holdout | NOT_REPRODUCED | Today-rain punctuation variant matches; 今日有雨 does not. Matcher is lexical ratio 0.8, not semantic protection. Known case IDs remain holdout; training_allowed=false universally |

## Six predeclared runs

Order: V4-r1, V5-r1, V4-r2, V5-r2, V4-r3, V5-r3. Each uses a fresh server. No result-selective reruns. Commands, timestamps and exits are in series.json and each environment.json.

| Run | Completed / blocked / truncated / error | Failed automatic gates | Persona hashes & all run controls |

|---|---|---|---|

| qwen4b-q4-v4-r1 | 75 / 4 / 2 / 0 | None | True |

| qwen4b-q4-v5-r1 | 71 / 9 / 1 / 0 | None | True |

| qwen4b-q4-v4-r2 | 77 / 2 / 2 / 0 | None | True |

| qwen4b-q4-v5-r2 | 67 / 10 / 4 / 0 | plain_maths_was_allowed | True |

| qwen4b-q4-v4-r3 | 71 / 7 / 3 / 0 | None | True |

| qwen4b-q4-v5-r3 | 70 / 6 / 5 / 0 | None | True |

## Comparability audit

```json

{
  "code_revision": true,
  "tree_sha": true,
  "patch_sha256": true,
  "server_sha256": true,
  "model_sha256": true,
  "runtime_config_sha256": true,
  "deployment_sha256": true,
  "seed_sha256": true,
  "chat_template_sha256": true,
  "server_command": true,
  "inputs": true,
  "sampling": true,
  "tracked_files_still_match": true,
  "tracked_diff_clean": true
}

```

Per-run true/false checks, expected persona hashes, F3 receipt reaching sent_messages, model/template/build and isolated data are in independent-audit.json. Missing evidence is not treated as equality. The sole declared experimental variable is the entire persona_projection bundle; no individual removed sentence is isolated. Clock/progression and sampled outputs vary naturally. Three repetitions give descriptive spread, not statistical significance.

## Metric spread (min / median / max)

Counters are heuristics on completed non-empty turns; blocked/truncated prefixes are exported separately. Question marks, silence and shorter responses are not success by themselves.

| Metric | V4 | V5 |

|---|---|---|

| profile.all.hands_back | 0.623 / 0.676 / 0.693 | 0.437 / 0.486 / 0.537 |

| profile.all.hands_back_casual | 0.667 / 0.698 / 0.706 | 0.46 / 0.508 / 0.574 |

| profile.all.trait_echo | 0.028 / 0.039 / 0.053 | 0.03 / 0.07 / 0.1 |

| profile.all.past_claim_unprompted | 0.0 / 0.027 / 0.028 | 0.014 / 0.014 / 0.015 |

| profile.all.closing_offer | 0.04 / 0.091 / 0.113 | 0.085 / 0.119 / 0.157 |

| profile.all.question_end_rate | 0.506 / 0.521 / 0.547 | 0.268 / 0.3 / 0.388 |

| profile.casual_share_probes.hands_back | 0.5 / 0.5 / 0.833 | 0.333 / 0.667 / 0.833 |

| profile.casual_share_probes.hands_back_casual | 0.5 / 0.5 / 0.833 | 0.333 / 0.667 / 0.833 |

| profile.casual_share_probes.trait_echo | 0.0 / 0.0 / 0.0 | 0.0 / 0.0 / 0.0 |

| profile.casual_share_probes.past_claim_unprompted | 0.0 / 0.0 / 0.0 | 0.0 / 0.0 / 0.0 |

| profile.casual_share_probes.closing_offer | 0.0 / 0.0 / 0.167 | 0.0 / 0.167 / 0.333 |

| profile.casual_share_probes.question_end_rate | 0.167 / 0.333 / 0.667 | 0.167 / 0.333 / 0.667 |

| profile.first_turn_of_case.hands_back | 0.667 / 0.722 / 0.722 | 0.438 / 0.556 / 0.588 |

| profile.first_turn_of_case.hands_back_casual | 0.647 / 0.706 / 0.765 | 0.4 / 0.588 / 0.625 |

| profile.first_turn_of_case.trait_echo | 0.056 / 0.111 / 0.111 | 0.056 / 0.118 / 0.125 |

| profile.first_turn_of_case.past_claim_unprompted | 0.0 / 0.0 / 0.0 | 0.0 / 0.0 / 0.0 |

| profile.first_turn_of_case.closing_offer | 0.111 / 0.167 / 0.167 | 0.0 / 0.118 / 0.167 |

| profile.first_turn_of_case.question_end_rate | 0.5 / 0.5 / 0.556 | 0.375 / 0.389 / 0.412 |

| profile.later_turns.hands_back | 0.61 / 0.66 / 0.684 | 0.436 / 0.453 / 0.531 |

| profile.later_turns.hands_back_casual | 0.673 / 0.674 / 0.706 | 0.468 / 0.479 / 0.568 |

| profile.later_turns.trait_echo | 0.017 / 0.019 / 0.035 | 0.02 / 0.055 / 0.094 |

| profile.later_turns.past_claim_unprompted | 0.0 / 0.035 / 0.038 | 0.018 / 0.019 / 0.02 |

| profile.later_turns.closing_offer | 0.018 / 0.068 / 0.094 | 0.102 / 0.109 / 0.17 |

| profile.later_turns.question_end_rate | 0.492 / 0.528 / 0.561 | 0.236 / 0.264 / 0.388 |

| median_casual_chars | 149 / 195 / 207 | 294 / 342 / 355 |

| blocked_rate | 0.025 / 0.049 / 0.086 | 0.074 / 0.111 / 0.123 |

| zero_visible_rate | 0.0 / 0.0 / 0.037 | 0.025 / 0.025 / 0.037 |

## A–T evidence index and review status

This is a complete category/run evidence index, NOT a completed semantic verdict table. Source-linked quotes are provided below for every arm/repetition. Problem status (present / partial / absent) and better/same/worse/within-spread labels require independent reading; they are deliberately NOT_CHECKED where not established. Categories Q/R/T are causal hypotheses, not identifiable from this single bundled intervention. Silence is never labelled absence of a defect.

See taxonomy-evidence.json and taxonomy-excerpts.md for all 20 categories x 6 runs. Full transcripts preserve every raw generation, system prompt, plan, guard and released segment. These are non-blind materials.

## Hard-integrity review and hypotheses a–g

D/E/F/G/M semantic regressions are not fully adjudicated. Automated gates alone cannot establish NONE. Promotion is blocked pending review. Hypotheses (a) rule recitation, (b) service framing, (c) fabricated experience/action, (d) identity frames, (e) factual pushback, (f) bracketed asides, and (g) tool-menu offers remain PENDING_SEMANTIC_REVIEW. Numerical counters above can inform a–b but cannot decide them. The retained tool menu and the lack of R2/R3 are design facts, not evidence that either future proposal will solve these failures.

Positive warmth, humour, curiosity, grounded initiative, useful requested help and necessary clarification must be reviewed alongside failures; no positive scores were fabricated here.

## Blind review and next action

Packets: reviewer/blind-r1.json, reviewer/blind-r2.json, reviewer/blind-r3.json. Keys are in keys/ and were not read by Codex. Do not send non-blind transcripts, taxonomy excerpts or this report to the same reviewer before their blind judgment. No owner judgments were supplied; ingest-review was not run. Store C:/XIYIN/candidate-store/v5-20260924 was only initialized and checked (all record files empty).

Claude should independently read the local diff, complete the A–T and a–g semantic review, and return case#turn evidence for each claim. Codex can then reconcile blind judgments and issue the next local test decision. Any just-in-time tool menu, R2/R3, history compaction or 9B work is a separate proposal, not implemented here.

## Limits and rollback

Budget protection stopped expansion and full semantic adjudication; it did not change the six-run order or skip raw evidence capture. No cloud inference, production-data access, training, merge, push or default change. All ASR/TTS/live-stream/body performance remains untested. Full local logs preserve initial environment failures and deterministic red tests.

Rollback: production needs none. Keep this isolated worktree and evidence. To undo only Codex changes in a fresh scratch checkout of the tested commit, first run git apply --reverse --check <absolute-path-to-combined-local.patch>, then apply the reverse after confirming no later edits. Do not reset/delete other worktrees or historical evidence.

## Final status

COMPARISON: VALID

V5_VS_V4: NOT_DETERMINED_PENDING_SEMANTIC_REVIEW

HARD_INTEGRITY_REGRESSION: NOT_DETERMINED_PENDING_SEMANTIC_REVIEW

REAL_MODEL_ACCEPTANCE: PENDING_BLIND_REVIEW

MERGE_STATUS: DO_NOT_MERGE