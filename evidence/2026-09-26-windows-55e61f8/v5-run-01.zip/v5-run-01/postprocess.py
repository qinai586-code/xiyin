import sys,json,hashlib,statistics,subprocess,contextlib
from pathlib import Path
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[1]; sys.path.insert(0,str(ROOT))
from tools import acceptance_dialogue as h
labels=[f"qwen4b-q4-{v}-r{n}" for n in (1,2,3) for v in ("v4","v5")]
EXPECTED={"v4:private":"f5c510d15eee96dba81e7c4bfe3c4f8ed49d05940fdd905b19724f216880c705","v4:public":"e00bbc46cd47bed6ecb35d3e2ec01aae5be7df50324b2606864bff0cd6cacfbe","v5:private":"d54c8cb657a691478fcd2ec8f7c10890aed270602616b35304867cf06699c131","v5:public":"4fdbbb4d248a719f76c2bdff40d3ef6eb26ad4ae401adf1a9b998e45f2ae426a"}
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
state=read(OUT/"tested-state.json"); results={}; envs=[]; samples=[]; inputs=[]
for label in labels:
 folder=OUT/label; d=read(folder/"dialogue.json"); e=read(folder/"environment.json"); props=read(folder/"props.json"); envs.append(e)
 turns=[(c["id"],i+1,t) for c in d["cases"] for i,t in enumerate(c["turns"])]
 sig=[(c,i,t["input"],t.get("scope","private")) for c,i,t in turns]; inputs.append(sig)
 wanted=[(c["id"],i+1,t["text"],t.get("scope","private")) for c in h.CASES for i,t in enumerate(c["turns"])]
 f3=next(c for c in d["cases"] if c["id"]=="F3_action_denial"); sent=f3["turns"][0]["sent_messages"][0]["content"]
 sample=d["model"]["server_sampling"]; samples.append(sample["settings"])
 checks={"exact_81_inputs_order_scope":len(turns)==81 and sig==wanted,"persona_hashes":all(t["plan"]["persona_sha256"]==EXPECTED[e["projection"]+":"+t.get("scope","private")] for c,i,t in turns),"model_pin":e["model_sha256"]=="13c16f426047e2de38cd075bdade4a7bcbc8c774384876f677740cda65f8a983"==d["model"]["identity"]["file"]["sha256"],"build":sample["server"]["build_info"]=="b11062-3cf03257f","template_hash":bool(props.get("chat_template")) and hashlib.sha256(props["chat_template"].encode()).hexdigest()==e["chat_template_sha256"],"integrated_commit":e["code_revision"]==state["tested_commit"]==d["code_revision"],"tree":e["tree_sha"]==state["tree"],"no_override":d["model"]["sent_sampling"]=={} and d["model"]["enable_thinking"] is False,"isolated_data":d["isolated_data_root"] is True and d["production_data_used"] is False,"receipt_reaches_F3":all(x in sent for x in ("动作执行回执","已执行并通过独立校验","acceptance_note.txt")),"actual_write":f3["setup"]["file_exists"] is True and f3["setup"]["job_status"]=="completed","source_unchanged":e["source_patch_unchanged"],"capture_exit":e["test_exit_code"]==0,"V5_no_move":all(t["plan"].get("move") is None for _,_,t in turns) if e["projection"]=="v5" else True}
 profile=h._service_profile(d); results[label]={"audit":checks,"totals":d["totals"],"gates":d["checks"]["gates"],"service_profile":profile,"blocked_rate":d["checks"]["blocked_rate"],"zero_visible_rate":d["checks"]["zero_visible_rate"],"partial_releases":[{"case":c,"turn":i,"status":t["status"],"released_text":t["released_text"],"guard":t.get("guard_reason")} for c,i,t in turns if t["status"]!="completed"],"dialogue_sha256":sha(folder/"dialogue.json")}
 md=["# "+label+" — full non-blind transcript","Source: dialogue.json; SHA-256: "+sha(folder/"dialogue.json")]
 for c,i,t in turns:
  md += [f"## {c}#{i}","User: "+t["input"],"Status: "+t["status"],"### Released text",t["released_text"],"### Raw generation",t.get("raw_generation") or "", "### Plan / move, guard and released segments","````json",json.dumps({k:t.get(k) for k in ("plan","guard_reason","detail","released_segments")},ensure_ascii=False,indent=2),"````","### System prompt",t["sent_messages"][0]["content"]]
 (folder/"full-transcript.md").write_text("\n\n".join(md),encoding="utf-8")
common=("code_revision","tree_sha","patch_sha256","server_sha256","model_sha256","runtime_config_sha256","deployment_sha256","seed_sha256","chat_template_sha256","server_command")
controls={k:all(e.get(k) is not None for e in envs) and len({json.dumps(e[k],sort_keys=True) for e in envs})==1 for k in common}
controls.update(inputs=all(x==inputs[0] for x in inputs),sampling=all(x==samples[0] for x in samples),tracked_files_still_match=all(sha(ROOT/f)==v for f,v in state["changed_files"].items()),tracked_diff_clean=not subprocess.check_output(["git","diff","HEAD","--"],cwd=ROOT))
spread={}
for v in ("v4","v5"):
 flat={}
 def flatten(x,prefix=""):
  for k,val in x.items():
   key=prefix+k
   if isinstance(val,dict):flatten(val,key+".")
   elif isinstance(val,(int,float)) and not isinstance(val,bool):flat.setdefault(key,[]).append(val)
 for label in labels:
  if "-"+v+"-" in label:
   x=results[label]; flatten({"profile":{g:x["service_profile"][g] for g in ("all","casual_share_probes","first_turn_of_case","later_turns")},"median_casual_chars":x["service_profile"]["median_casual_chars"],"blocked_rate":x["blocked_rate"],"zero_visible_rate":x["zero_visible_rate"]})
 spread[v]={k:{"min":min(a),"median":statistics.median(a),"max":max(a),"n":len(a)} for k,a in flat.items()}
valid=all(controls.values()) and all(all(x["audit"].values()) for x in results.values())
save(OUT/"independent-audit.json",{"comparison_valid":valid,"controls":controls,"arms":results,"spread":spread})
with (OUT/"compare-all.json").open("w",encoding="utf-8") as f:
 with contextlib.redirect_stdout(f):h.compare([OUT/l/"dialogue.json" for l in labels])
(OUT/"reviewer").mkdir(exist_ok=True); (OUT/"keys").mkdir(exist_ok=True)
for n in (1,2,3):
 h.blind([OUT/f"qwen4b-q4-{v}-r{n}"/"dialogue.json" for v in ("v4","v5")],OUT/"reviewer"/f"blind-r{n}.json",OUT/"keys"/f"key-r{n}.json")
print(json.dumps({"valid":valid,"controls":controls,"runs":{k:{"totals":v["totals"],"failed_gates":[n for n,x in v["gates"].items() if x is not True],"casual":v["service_profile"]["casual_share_probes"]["hands_back"],"later":v["service_profile"]["later_turns"]["hands_back"]} for k,v in results.items()}},ensure_ascii=False))
