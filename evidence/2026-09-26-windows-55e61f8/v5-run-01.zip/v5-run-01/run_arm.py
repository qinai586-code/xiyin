"""Local evidence runner; owns only the server and test processes it starts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import urlopen

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SERVER = Path(r"D:\cuda\bin\llama-server.exe")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def command(args):
    return subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--projection", choices=("v4", "v5"), required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()
    dest = OUT / args.label
    dest.mkdir(exist_ok=False)
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    flags = [str(SERVER), "--model", args.model, "--host", "127.0.0.1", "--port", "8080",
             "--alias", "xiyin", "--ctx-size", "4096", "--parallel", "1", "--n-gpu-layers", "999",
             "--jinja", "--chat-template-kwargs", '{"enable_thinking":false}', "--no-mmproj-auto"]
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=ROOT)
    (dest / "tested.patch").write_bytes(diff)
    info = {"label": args.label, "projection": args.projection, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "cwd": str(ROOT), "python": sys.version, "code_revision": command(["git", "rev-parse", "HEAD"]).stdout.strip(),
            "patch_sha256": hashlib.sha256(diff).hexdigest(), "tree_sha": command(["git", "rev-parse", "HEAD^{tree}"]).stdout.strip(), "model_file": args.model,
            "model_sha256": sha(args.model), "model_bytes": Path(args.model).stat().st_size,
            "server_sha256": sha(SERVER), "server_command": flags,
            "server_version": command([str(SERVER), "--version"]).stdout,
            "runtime_config_sha256": sha(ROOT / "config/runtime.toml"),
            "deployment_sha256": sha(ROOT / "config/deployment.toml"),
            "seed_sha256": sha(ROOT / "config/persona/character.seed.json")}
    save(dest / "environment.json", info)
    probe = socket.socket()
    try:
        if probe.connect_ex(("127.0.0.1", 8080)) == 0:
            raise RuntimeError("Port 8080 already in use; no unrelated process will be stopped")
    finally:
        probe.close()
    server = test = None
    samples = []
    creation = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result_code = 1
    try:
        with (dest / "server.stdout.log").open("w", encoding="utf-8") as so, (dest / "server.stderr.log").open("w", encoding="utf-8") as se:
            server = subprocess.Popen(flags, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=creation)
            info["server_pid"] = server.pid
            for _ in range(120):
                if server.poll() is not None:
                    raise RuntimeError(f"Server exited {server.returncode}")
                try:
                    with urlopen("http://127.0.0.1:8080/props", timeout=2) as response:
                        props = json.load(response)
                    break
                except Exception:
                    time.sleep(1)
            else:
                raise TimeoutError("Model server did not become ready")
            save(dest / "props.json", props)
            info["chat_template_sha256"] = hashlib.sha256(str(props.get("chat_template", "")).encode()).hexdigest()
            report = dest / "dialogue.json"
            test_cmd = [sys.executable, "-B", "tools/acceptance_dialogue.py", "--label", args.label,
                        "--persona-projection", args.projection, "--model-file", args.model, "--out", str(report)]
            info["test_command"] = test_cmd
            save(dest / "environment.json", info)
            print(f"START {args.label}; server_pid={server.pid}", flush=True)
            started = time.monotonic()
            with (dest / "test.log").open("w", encoding="utf-8") as log:
                test = subprocess.Popen(test_cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=creation)
                while test.poll() is None:
                    gpu = command(["nvidia-smi", "--query-gpu=memory.used,memory.free,utilization.gpu", "--format=csv,noheader,nounits"])
                    samples.append({"elapsed_seconds": round(time.monotonic() - started, 2), "raw": gpu.stdout.strip(), "exit_code": gpu.returncode})
                    with (dest / "gpu-samples.jsonl").open("a", encoding="utf-8") as sample_log:
                        sample_log.write(json.dumps(samples[-1]) + "\n")
                        sample_log.flush()
                        os.fsync(sample_log.fileno())
                    if time.monotonic() - started > 2400:
                        raise TimeoutError("Dialogue arm exceeded 40 minutes")
                    time.sleep(2)
                result_code = test.returncode
            info["test_exit_code"] = result_code
            info["elapsed_seconds"] = round(time.monotonic() - started, 2)
            if report.is_file():
                data = json.loads(report.read_text(encoding="utf-8"))
                print(json.dumps({"label": args.label, "totals": data["totals"], "gates": data["checks"]["gates"]}, ensure_ascii=False), flush=True)
    except BaseException as exc:
        info["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        for child in (test, server):
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=10)
        info["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        info["source_patch_unchanged"] = diff == subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=ROOT)
        save(dest / "environment.json", info)
        save(dest / "gpu-samples.json", samples)
    return result_code


if __name__ == "__main__":
    raise SystemExit(main())
