import json, os, subprocess, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
labels = [f"qwen4b-q4-{v}-r{n}" for n in (1, 2, 3) for v in ("v4", "v5")]
state = {"predeclared_order": labels, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "commands": []}
(OUT / "series.json").write_text(json.dumps(state, indent=2), encoding="utf-8")
for label in labels:
    projection = label.split("-")[2]
    cmd = [sys.executable, "-B", str(OUT / "run_arm.py"), "--projection", projection, "--label", label, "--model", r"D:\cuda\model\Qwen_Qwen3.5-4B-Q4_K_M.gguf"]
    item = {"label": label, "argv": cmd, "cwd": str(ROOT), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    state["commands"].append(item)
    (OUT / "series.json").write_text(json.dumps(state, indent=2), encoding="utf-8")
    with (OUT / (label + ".runner.log")).open("w", encoding="utf-8") as log:
        result = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    item.update(exit_code=result.returncode, finished_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    (OUT / "series.json").write_text(json.dumps(state, indent=2), encoding="utf-8")
    print(label, "exit", result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
